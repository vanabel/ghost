package cn.yourdomain.listmusic.listmusic;

import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FilenameFilter;

public class ListMusicActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_music);

        LinearLayout view = (LinearLayout) findViewById(R.id.view);
        //the root path
        File root = new File (Environment.getExternalStorageDirectory().toString()+"/music");
        File files[]=root.listFiles(new FilenameFilter(){
            @Override
            public boolean accept(File file, String s) {
                return s.toLowerCase().endsWith(".flac")||s.toLowerCase().endsWith(".mp3");
            }
        });
        for (File fi: files) {
            TextView textView = new TextView(this);
            textView.setText(fi.getName());
            textView.setPadding(5, 5, 5, 5);
            view.addView(textView);
        }
    }
}
